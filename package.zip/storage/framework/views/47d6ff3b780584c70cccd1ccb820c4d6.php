<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-right">
            قائمة المعدات
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm rounded-lg p-6">
                <?php if(session('success')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-center">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <div class="flex justify-end mb-4">
                    <a href="<?php echo e(route('equipment.create')); ?>"
                       class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                        إضافة معدة جديدة
                    </a>
                </div>

                <table class="min-w-full divide-y divide-gray-200 text-right">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase">#</th>
                            <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase">اسم المعدة</th>
                            <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase">الحالة</th>
                            <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase">الكمية</th>
                            <th class="px-6 py-3 text-xs font-medium text-gray-500 uppercase">الصورة</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4"><?php echo e($loop->iteration); ?></td>
                                <td class="px-6 py-4"><?php echo e($equipment->name); ?></td>
                                <td class="px-6 py-4"><?php echo e($equipment->status); ?></td>
                                <td class="px-6 py-4"><?php echo e($equipment->quantity); ?></td>
                               <td class="px-6 py-4">

                                 <!--  عرض صورة المعدة إذا كانت موجودة -->
                                 <?php if($equipment->image): ?>
                                  <img src="<?php echo e(Storage::url($equipment->image->path)); ?>" alt="صورة المعدة " style="width:150px; height:auto;">
                                 <?php else: ?> 
                                  <p> لا توجد صورة </p>
                                 <?php endif; ?>  

                                <td class="px-6 py-4 flex gap-2 justify-end">
                                    <a href="<?php echo e(route('equipment.edit', $equipment->id)); ?>"
                                       class="text-indigo-600 hover:text-indigo-900">تعديل</a>
                                    <form action="<?php echo e(route('equipment.destroy', $equipment->id)); ?>" method="POST"
                                          onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900">حذف</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\MSI\Desktop\New folder\gym-management-system\resources\views/Equipment/index.blade.php ENDPATH**/ ?>