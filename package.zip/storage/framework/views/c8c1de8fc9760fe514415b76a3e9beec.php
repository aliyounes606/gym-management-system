<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight text-right">
            تعديل بيانات المعدة
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-md mx-auto sm:px-6 lg:px-8 bg-white p-6 rounded shadow">
            <form action="<?php echo e(route('equipment.update', $equipment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label class="block text-gray-700">اسم المعدة</label>
                    <input type="text" name="name" class="w-full border-gray-300 rounded" value="<?php echo e($equipment->name); ?>" required>
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-700"> الحالة</label>
                    <input type="text" name="status" class="w-full border-gray-300 rounded" value="<?php echo e($equipment->status); ?>" required>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700"> الكمية</label>
                    <input type="number" name="quantity" class="w-full border-gray-300 rounded" value="<?php echo e($equipment->quantity); ?>" required>
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">التصنيفات</label>
                    <select name="categories[]" multiple class="w-full border-gray-300 rounded">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"
                                <?php echo e($equipment->categories->contains($category->id) ? 'selected' : ''); ?>> <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <!-- عرض الصورة الحالية -->
                 <?php if($equipment->image): ?>
                 <div class="mb-4">
                   <img src="<?php echo e(Storage::url($equipment->image->path)); ?>" alt="صورة المعدة " style="width:150px; height:auto;">
                         <?php else: ?> 
                            <p> لا توجد صورة </p>
                <?php endif; ?>
                 </div>

                <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">
                    تحديث
                </button>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\MSI\Desktop\New folder\gym-management-system\resources\views/equipment/edit.blade.php ENDPATH**/ ?>