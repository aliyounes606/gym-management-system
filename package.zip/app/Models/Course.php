<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class Course extends Model
{
    //

  protected $table = "courses"; 
    protected $fillable =[
        "name",
        "description",
        "trainer_profile_id",
        "total_price"
    ];
    
 
public function sessions()
{
    return $this->hasMany(GymSession::class, 'course_id');
}
public function trainerProfile()
{
    return $this->belongsTo(TrainerProfile::class, 'trainer_profile_id');
}
}
