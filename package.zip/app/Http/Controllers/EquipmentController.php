<?php

namespace App\Http\Controllers;

use App\Models\Equipment;
use App\Models\Category;
//use App\Http\Requests\Admin\StoreCourseRequest;
use App\Http\Requests\StoreEquipmentRequest;
use App\Http\Requests\UpdateEquipmentRequest;

//use App\Http\Requests\Admin\UpdateEquipmentRequest;

class EquipmentController extends Controller
{
    // عرض كل المعدات
    public function index()
    {
        $equipment = Equipment::all();
        return view('Equipment.index', compact('equipment'));
    }

    // عرض فورم إنشاء معدة جديدة
    public function create()
{    
    $categories=Category::all();
    return view('equipment.create',compact('categories'));
}


    // حفظ المعدة الجديدة
    public function store(StoreEquipmentRequest $request)
    {
        //$validated = $request->validated();
        $equipment = Equipment::create($request->validated());
        if($request->hasFile('image')){
            $imagePath=$request->file('image')->store('public/equipment_images');
        $equipment->image()->create(['path'=>'equipment_images/' . basename($imagePath),'filename'=>basename($imagePath),]);}

        $equipment->categories()->attach($request->categories);

        return redirect()->route('equipment.index', $equipment->id)
                         ->with('success','تم حفظ المعدة بنجاح');
    }

    // عرض معدة محددة
    public function show($id)
    {
        $equipment = Equipment::findOrFail($id);
        return view('equipment.show', compact('equipment'));
    }

    // عرض فورم تعديل معدة
    public function edit($id)
    {
        $equipment = Equipment::findOrFail($id);

        $categories=Category::all();
        return view('equipment.edit', compact('equipment','categories'));
    }

    // تحديث المعدة
    public function update(UpdateEquipmentRequest $request, $id)
    {
        //$validated = $request->validated();

        $equipment = Equipment::findOrFail($id);
        $equipment->update($request->validated());
        //في حال تم إرسال صورة جديدة نقوم بنعديل الصورة
         if ($request->hasFile('image')){
            $equipment->image()->delete();        //حذف الصورة القديمة
            $request->storeImage($equipment);     //تخزين الصورة ال
        }

        $equipment->categories()->sync($request->categories);

        return redirect()->route('equipment.index')
                         ->with('success','تم تحديث المعدة بنجاح');
    }

    // حذف المعدة
    public function destroy($id)
    {
        Equipment::destroy($id);
        return redirect()->route('equipment.index')
                         ->with('success','تم حذف المعدة');
    }
}
